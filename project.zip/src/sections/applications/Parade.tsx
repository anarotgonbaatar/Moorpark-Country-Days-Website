export default function Parade() {
	return (
		<div className="app-content">
			
		</div>
	)
}