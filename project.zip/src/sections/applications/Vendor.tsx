export default function Parade() {
	return (
		<div>
			
		</div>
	)
}